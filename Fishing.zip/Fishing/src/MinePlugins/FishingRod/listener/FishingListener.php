<?php
declare(strict_types=1);

namespace MinePlugins\FishingRod\listener;

use MinePlugins\FishingRod\enchantment\EnchantmentHelper;
use MinePlugins\FishingRod\FishingSession;
use MinePlugins\FishingRod\Main;
use MinePlugins\FishingRod\task\HookTickTask;
use MinePlugins\FishingRod\utils\HookLauncher;
use MinePlugins\FishingRod\utils\SoundHelper;
use pocketmine\event\EventPriority;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\item\VanillaItems;
use pocketmine\network\mcpe\protocol\InventoryTransactionPacket;
use pocketmine\network\mcpe\protocol\types\inventory\UseItemTransactionData;

class FishingListener implements Listener {

    private HookTickTask $tickTask;
    private array $lastUseTick = [];

    public function __construct(private readonly Main $plugin) {
        $this->tickTask = new HookTickTask($plugin);
        $plugin->getScheduler()->scheduleRepeatingTask($this->tickTask, 1);

        $mgr = $plugin->getServer()->getPluginManager();

        $mgr->registerEvent(DataPacketReceiveEvent::class, \Closure::fromCallable([$this, 'onPacket']), EventPriority::HIGHEST, $plugin, true);
        $mgr->registerEvent(PlayerItemHeldEvent::class,    \Closure::fromCallable([$this, 'onItemHeld']), EventPriority::NORMAL, $plugin, false);
        $mgr->registerEvent(PlayerQuitEvent::class,        \Closure::fromCallable([$this, 'onQuit']), EventPriority::NORMAL, $plugin, false);
        $mgr->registerEvent(PlayerDeathEvent::class,       \Closure::fromCallable([$this, 'onDeath']), EventPriority::NORMAL, $plugin, false);
    }

    public function onPacket(DataPacketReceiveEvent $event): void {
        $packet = $event->getPacket();
        if (!($packet instanceof InventoryTransactionPacket)) return;

        $data = $packet->trData;
        if (!($data instanceof UseItemTransactionData)) return;

        $action = $data->getActionType();
        if ($action !== UseItemTransactionData::ACTION_CLICK_AIR && $action !== UseItemTransactionData::ACTION_CLICK_BLOCK) return;

        $player = $event->getOrigin()->getPlayer();
        if ($player === null || !$player->isOnline()) return;

        $item = $player->getInventory()->getItemInHand();
        if (!$item->equals(VanillaItems::FISHING_ROD(), false, false)) return;

        $name = $player->getName();
        $tick = $this->plugin->getServer()->getTick();

        if (isset($this->lastUseTick[$name]) && $this->lastUseTick[$name] === $tick) return;
        $this->lastUseTick[$name] = $tick;

        if ($this->plugin->hasSession($name)) {
            $session = $this->plugin->getSession($name);
            if ($session !== null) {
                $this->tickTask->reel($session, $name);
            }
            return;
        }

        $hook = HookLauncher::launch($player);
        if ($hook === null) return;

        $cfg  = $this->plugin->getConfig();
        $min  = (int)$cfg->getNested("fishing.bite_time_min", 5) * 20;
        $max  = (int)$cfg->getNested("fishing.bite_time_max", 30) * 20;
        $win  = (int)$cfg->getNested("fishing.bite_window", 3) * 20;
        $wait = mt_rand($min, $max);

        $session = new FishingSession($player, $hook, $tick + $wait, $tick + $wait + $win);
        $this->plugin->createSession($name, $session);
    }

    public function onItemHeld(PlayerItemHeldEvent $event): void {
        $name = $event->getPlayer()->getName();
        if (!$this->plugin->hasSession($name)) return;

        $newItem = $event->getPlayer()->getInventory()->getItem($event->getSlot());
        if (!$newItem->equals(VanillaItems::FISHING_ROD(), false, false)) {
            $this->plugin->getSession($name)?->destroy();
            $this->plugin->removeSession($name);
        }
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $name = $event->getPlayer()->getName();
        $this->plugin->getSession($name)?->destroy();
        $this->plugin->removeSession($name);
        unset($this->lastUseTick[$name]);
    }

    public function onDeath(PlayerDeathEvent $event): void {
        $player = $event->getPlayer();
        $name   = $player->getName();

        $this->plugin->getSession($name)?->destroy();
        $this->plugin->removeSession($name);

        $drops = $event->getDrops();
        foreach ($drops as $key => $drop) {
            if ($drop->equals(VanillaItems::FISHING_ROD(), false, false) && EnchantmentHelper::hasVanishingCurse($drop)) {
                unset($drops[$key]);
            }
        }
        $event->setDrops(array_values($drops));
    }
}
