<?php
declare(strict_types=1);

namespace MinePlugins\FishingRod\utils;

use MinePlugins\FishingRod\entity\FishingHookEntity;
use pocketmine\entity\Location;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\player\Player;

class HookLauncher {

    public static function launch(Player $player): ?FishingHookEntity {
        $world = $player->getWorld();
        $loc   = $player->getLocation();
        $eyePos  = $player->getEyePos();
        $hookLoc = new Location(
            $eyePos->x,
            $eyePos->y,
            $eyePos->z,
            $world,
            $loc->yaw,
            $loc->pitch
        );

        try {
            $hook = new FishingHookEntity($hookLoc, $player, CompoundTag::create());
            $hook->setMotion(self::calcVelocity($loc->yaw, $loc->pitch));
            $hook->spawnToAll();
            return $hook;
        } catch (\Throwable $e) {
            $player->getServer()->getLogger()->error("[FishingRod] Ошибка спавна крючка: " . $e->getMessage());
            return null;
        }
    }
    private static function calcVelocity(float $yaw, float $pitch): Vector3 {
        $yRad = deg2rad($yaw);
        $pRad = deg2rad($pitch);
        $spd  = 0.5;

        $vx = -sin($yRad) * cos($pRad) * $spd;
        $vy = -sin($pRad) * $spd + 0.1;
        $vz =  cos($yRad) * cos($pRad) * $spd;
      
        $vx += (lcg_value() - 0.5) * 0.005;
        $vy += (lcg_value() - 0.5) * 0.005;
        $vz += (lcg_value() - 0.5) * 0.005;

        return new Vector3($vx, $vy, $vz);
    }
}