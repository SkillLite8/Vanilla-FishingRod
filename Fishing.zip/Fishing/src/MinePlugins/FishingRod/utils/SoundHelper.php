<?php
declare(strict_types=1);

namespace MinePlugins\FishingRod\utils;

use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\player\Player;

class SoundHelper {

    private static function send(Player $player, string $sound, float $vol, float $pitch): void {
        $pos = $player->getLocation();
        $pk  = PlaySoundPacket::create($sound, $pos->x, $pos->y, $pos->z, $vol, $pitch);
        $player->getNetworkSession()->sendDataPacket($pk);
    }
    public static function playCast(Player $player): void {
        self::send($player, "random.bow", 0.5, 1.0);
    }
    public static function playBite(Player $player): void {
        self::send($player, "random.splash", 0.25, 1.0);
    }
    public static function playReel(Player $player): void {
        self::send($player, "random.splash", 1.0, 1.0);
    }

    public static function playBreak(Player $player): void {
        self::send($player, "random.break", 1.0, 1.0);
    }
}