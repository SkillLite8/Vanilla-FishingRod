<?php
declare(strict_types=1);

namespace MinePlugins\FishingRod;

use MinePlugins\FishingRod\entity\FishingHookEntity;
use MinePlugins\FishingRod\listener\FishingListener;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\EntityFactory;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\plugin\PluginBase;
use pocketmine\world\World;

class Main extends PluginBase {

    private static Main $instance;
    private array $sessions = [];

    public function onEnable(): void {
        self::$instance = $this;

        $this->saveDefaultConfig();
        $this->saveResource("config.yml", false);
        EntityFactory::getInstance()->register(
            FishingHookEntity::class,
            function(World $world, CompoundTag $nbt): FishingHookEntity {
                return new FishingHookEntity(
                    EntityDataHelper::parseLocation($nbt, $world),
                    null,
                    $nbt
                );
            },
            ['MinePluginsFishingHook']
        );

        $this->getServer()->getPluginManager()->registerEvents(
            new FishingListener($this),
            $this
        );

        $this->getLogger()->info("§7| MinePlugins");
    }

    public function onDisable(): void {
        foreach ($this->sessions as $session) {
            $session->destroy();
        }
        $this->sessions = [];
    }

    public static function getInstance(): Main {
        return self::$instance;
    }
    public function getSessions(): array {
        return $this->sessions;
    }

    public function getSession(string $name): ?FishingSession {
        return $this->sessions[$name] ?? null;
    }

    public function createSession(string $name, FishingSession $session): void {
        if (isset($this->sessions[$name])) { $this->sessions[$name]->destroy(); }
        $this->sessions[$name] = $session;
    }

    public function removeSession(string $name): void {
        unset($this->sessions[$name]);
    }

    public function hasSession(string $name): bool {
        return isset($this->sessions[$name]);
    }
}