<?php
declare(strict_types=1);

namespace MinePlugins\FishingRod;

use MinePlugins\FishingRod\entity\FishingHookEntity;
use pocketmine\player\Player;

class FishingSession {

    public const STATE_CAST     = 0;
    public const STATE_WAITING  = 1;
    public const STATE_TRAILING = 2;
    public const STATE_BITING   = 3;
    public const STATE_HOOKED   = 4;

    private int  $state     = self::STATE_CAST;
    private bool $destroyed = false;

    public function __construct(
        private readonly Player            $player,
        private readonly FishingHookEntity $hook,
        private int $biteTick,
        private int $windowTick
    ) {}

    public function getPlayer(): Player            { return $this->player; }
    public function getHook(): FishingHookEntity   { return $this->hook; }
    public function getState(): int                { return $this->state; }
    public function setState(int $state): void     { $this->state = $state; }
    public function getBiteTick(): int             { return $this->biteTick; }
    public function getWindowTick(): int           { return $this->windowTick; }

    public function resetTimers(int $bite, int $window): void {
        $this->biteTick   = $bite;
        $this->windowTick = $window;
    }

    public function destroy(): void {
        if (!$this->destroyed) {
            $this->destroyed = true;
            if (!$this->hook->isClosed()) $this->hook->flagForDespawn();
        }
    }

    public function isDestroyed(): bool { return $this->destroyed; }
}