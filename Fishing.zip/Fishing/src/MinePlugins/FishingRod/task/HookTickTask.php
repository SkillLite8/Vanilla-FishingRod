<?php
declare(strict_types=1);

namespace MinePlugins\FishingRod\task;

use MinePlugins\FishingRod\enchantment\EnchantmentHelper;
use MinePlugins\FishingRod\event\PlayerFishEvent;
use MinePlugins\FishingRod\FishingSession;
use MinePlugins\FishingRod\loot\LootTable;
use MinePlugins\FishingRod\Main;
use MinePlugins\FishingRod\utils\SoundHelper;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;
use pocketmine\scheduler\Task;

class HookTickTask extends Task {

    public function __construct(private readonly Main $plugin) {}

    public function onRun(): void {
        $tick = $this->plugin->getServer()->getTick();
        foreach ($this->plugin->getSessions() as $name => $session) {
            $this->tickSession($session, $tick, $name);
        }
    }

    private function tickSession(FishingSession $session, int $tick, string $name): void {
        $player = $session->getPlayer();
        $hook   = $session->getHook();

        if ($session->isDestroyed() || !$player->isOnline()) {
            $session->destroy();
            $this->plugin->removeSession($name);
            return;
        }

        if ($hook->isClosed() || $hook->isFlaggedForDespawn()) {
            $this->plugin->removeSession($name);
            return;
        }

        if ($hook->getHookedEntity() !== null && $session->getState() !== FishingSession::STATE_HOOKED) {
            $session->setState(FishingSession::STATE_HOOKED);
        }

        match ($session->getState()) {
            FishingSession::STATE_CAST     => $this->handleCast($session),
            FishingSession::STATE_WAITING  => $this->handleWaiting($session, $tick),
            FishingSession::STATE_TRAILING => $this->handleTrailing($session),
            FishingSession::STATE_BITING   => $this->handleBiting($session, $tick),
            FishingSession::STATE_HOOKED   => $this->handleHooked($session),
        };
    }

    private function handleCast(FishingSession $session): void {
        if ($session->getHook()->isInWater()) {
            $session->setState(FishingSession::STATE_WAITING);
        }
    }

    private function handleWaiting(FishingSession $session, int $tick): void {
        if (!$session->getHook()->isInWater()) {
            $session->setState(FishingSession::STATE_CAST);
            return;
        }
        if ($tick >= $session->getBiteTick()) {
            $session->getHook()->startTrail();
            $session->setState(FishingSession::STATE_TRAILING);
        }
    }

    private function handleTrailing(FishingSession $session): void {
        if (!$session->getHook()->isInWater()) {
            $session->setState(FishingSession::STATE_CAST);
            return;
        }
        if ($session->getHook()->isTrailDone()) {
            SoundHelper::playBite($session->getPlayer());
            $session->setState(FishingSession::STATE_BITING);
        }
    }

    private function handleBiting(FishingSession $session, int $tick): void {
        if ($tick >= $session->getWindowTick()) {
            $this->scheduleNewBite($session, $tick);
        }
    }

    private function handleHooked(FishingSession $session): void {
        $entity = $session->getHook()->getHookedEntity();
        if ($entity === null || $entity->isClosed()) {
            $session->setState(FishingSession::STATE_CAST);
        }
    }

    private function scheduleNewBite(FishingSession $session, int $tick): void {
        $cfg  = $this->plugin->getConfig();
        $min  = (int)$cfg->getNested("fishing.bite_time_min", 5) * 20;
        $max  = (int)$cfg->getNested("fishing.bite_time_max", 30) * 20;
        $win  = (int)$cfg->getNested("fishing.bite_window", 3) * 20;
        $wait = mt_rand($min, $max);
        $session->resetTimers($tick + $wait, $tick + $wait + $win);
        $session->setState(FishingSession::STATE_WAITING);
    }

    public function reel(FishingSession $session, string $name): bool {
        $player = $session->getPlayer();
        $state  = $session->getState();

        if ($state === FishingSession::STATE_HOOKED) {
            $hook   = $session->getHook();
            $entity = $hook->getHookedEntity();

            if ($entity !== null && !$entity->isClosed()) {
                $ownerPos  = $player->getLocation()->asVector3();
                $entityPos = $entity->getLocation()->asVector3();
                $diff      = $ownerPos->subtractVector($entityPos);
                $dist      = $diff->length();

                if ($dist > 0.1) {
                    $dir = $diff->normalize();
                    $entity->setMotion(new Vector3(
                        $dir->x * 0.4,
                        abs($dir->y) * 0.4 + 0.15,
                        $dir->z * 0.4
                    ));
                }
            }

            $session->destroy();
            $this->plugin->removeSession($name);

            $rod = $player->getInventory()->getItemInHand();
            if ($rod->equals(VanillaItems::FISHING_ROD(), false, false)) {
                EnchantmentHelper::damageRod($rod, $player, 5);
            }
            return true;
        }

        $gotFish = $state === FishingSession::STATE_BITING;
        $session->destroy();
        $this->plugin->removeSession($name);

        if (!$gotFish) return false;

        $rod = $player->getInventory()->getItemInHand();
        if (!$rod->equals(VanillaItems::FISHING_ROD(), false, false)) return false;

        $result   = LootTable::roll(EnchantmentHelper::getLevel($rod, "fortune"));
        $item     = $result["item"];
        $category = $result["category"];
        $extra    = EnchantmentHelper::applyFortune($rod) ? clone $item : null;

        $event = new PlayerFishEvent($player, $item, $category);
        $event->call();

        if ($event->isCancelled()) {
            EnchantmentHelper::damageRod($rod, $player);
            return false;
        }

        $finalItem = $event->getItem();
        $inv       = $player->getInventory();

        foreach (array_filter([$finalItem, $extra]) as $give) {
            $inv->canAddItem($give) ? $inv->addItem($give) : $player->getWorld()->dropItem($player->getLocation()->asVector3(), $give);
        }

        $xp        = (int)$this->plugin->getConfig()->getNested("fishing.xp_reward_" . $category, 1);
        $remaining = EnchantmentHelper::applyMending($rod, $player, $xp);
        if ($remaining > 0) $player->getXpManager()->addXp($remaining);

        $broken = EnchantmentHelper::damageRod($rod, $player);
        SoundHelper::playReel($player);
        if ($broken) SoundHelper::playBreak($player);

        return true;
    }
}