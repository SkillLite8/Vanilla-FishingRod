<?php
declare(strict_types=1);

namespace MinePlugins\FishingRod\enchantment;

use MinePlugins\FishingRod\Main;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\item\Item;
use pocketmine\player\Player;

class EnchantmentHelper {
  
    public static function getLevel(Item $rod, string $enchantName): int {
        $enchant = match ($enchantName) {
            "fortune"   => VanillaEnchantments::FORTUNE(),
            "unbreaking" => VanillaEnchantments::UNBREAKING(),
            "mending"   => VanillaEnchantments::MENDING(),
            "vanishing" => VanillaEnchantments::VANISHING(),
            default     => null
        };

        if ($enchant === null) return 0;

        $instance = $rod->getEnchantment($enchant);
        return $instance?->getLevel() ?? 0;
    }
    public static function applyFortune(Item $rod): bool {
        $level = self::getLevel($rod, "fortune");
        if ($level === 0) return false;

        $chance = Main::getInstance()
            ->getConfig()
            ->getNested("enchantments.fortune_bonus_chance_per_level", 0.1);

        return lcg_value() < ($level * $chance);
    }
    public static function shouldTakeDamage(Item $rod): bool {
        $level = self::getLevel($rod, "unbreaking");
        if ($level === 0) return true;
        return lcg_value() < (1.0 / ($level + 1));
    }
    public static function applyMending(Item $rod, Player $player, int $xpAvailable): int {
        if ($xpAvailable <= 0) return 0;
        if (self::getLevel($rod, "mending") === 0) return $xpAvailable;

        $xpPerDurability = (int) Main::getInstance()
            ->getConfig()
            ->getNested("enchantments.mending_xp_per_durability", 2);

        $damage    = $rod->getDamage();
        if ($damage === 0) return $xpAvailable; 
        $canRepair  = (int) floor($xpAvailable / $xpPerDurability);
        $toRepair   = min($canRepair, $damage);
        $xpSpent    = $toRepair * $xpPerDurability;

        $rod->setDamage($damage - $toRepair);

        return max(0, $xpAvailable - $xpSpent);
    }
    public static function hasVanishingCurse(Item $rod): bool {
        return self::getLevel($rod, "vanishing") > 0;
    }
    public static function damageRod(Item $rod, Player $player, int $damage = 1): bool {
        if (!self::shouldTakeDamage($rod)) {
            return false; 
        }

        $maxDurability = Main::getInstance()
            ->getConfig()
            ->getNested("fishing.rod_max_durability", 64);

        $newDamage = $rod->getDamage() + $damage;

        if ($newDamage >= $maxDurability) {
            $inv  = $player->getInventory();
            $slot = $inv->getHeldItemIndex();
            $inv->setItem($slot, $inv->getItem($slot)->setCount(0)); 
            return true;
        }

        $rod->setDamage($newDamage);
        $player->getInventory()->setItemInHand($rod);
        return false;
    }
}