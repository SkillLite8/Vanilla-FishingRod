<?php
declare(strict_types=1);

namespace MinePlugins\FishingRod\event;

use pocketmine\event\Cancellable;
use pocketmine\event\CancellableTrait;
use pocketmine\event\player\PlayerEvent;
use pocketmine\item\Item;
use pocketmine\player\Player;

class PlayerFishEvent extends PlayerEvent implements Cancellable {
    use CancellableTrait;

    public const CATEGORY_FISH     = "fish";
    public const CATEGORY_TREASURE = "treasure";
    public const CATEGORY_JUNK     = "junk";

    public function __construct(
        Player          $player,
        private Item    $item,
        private string  $category
    ) {
        $this->player = $player;
    }
    public function getItem(): Item {
        return $this->item;
    }
    public function setItem(Item $item): void {
        $this->item = $item;
    }
    public function getCategory(): string {
        return $this->category;
    }
}