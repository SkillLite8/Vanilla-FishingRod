<?php
declare(strict_types=1);

namespace MinePlugins\FishingRod\entity;

use pocketmine\block\Water;
use pocketmine\entity\Entity;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\Human;
use pocketmine\entity\Living;
use pocketmine\entity\Location;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\protocol\PlaySoundPacket;
use pocketmine\network\mcpe\protocol\SpawnParticleEffectPacket;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataCollection;
use pocketmine\network\mcpe\protocol\types\entity\EntityMetadataProperties;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\player\Player;

class FishingHookEntity extends Entity {

    protected function getInitialSizeInfo(): EntitySizeInfo { return new EntitySizeInfo(0.25, 0.25); }
    protected function getInitialDragMultiplier(): float { return 0.08; }
    protected function getInitialGravity(): float { return 0.03; }
    public static function getNetworkTypeId(): string { return EntityIds::FISHING_HOOK; }

    private ?Player $owner        = null;
    private bool    $inWater      = false;
    private ?Entity $hookedEntity = null;

    private bool  $trailActive   = false;
    private int   $trailTick     = 0;
    private int   $trailDuration = 0;
    private float $trailStartX   = 0.0;
    private float $trailStartZ   = 0.0;
    private float $waterSurfaceY = 0.0;
    private bool  $trailDone     = false;

    private int   $bobTick       = 0;
    private float $targetY       = 0.0;

    private const DRAG = 0.92;

    public function __construct(Location $location, ?Player $owner, CompoundTag $nbt) {
        parent::__construct($location, $nbt);
        $this->owner = $owner;
        $this->setCanSaveWithChunk(false);
        $this->setHasGravity(true);
    }

    protected function initEntity(CompoundTag $nbt): void {
        parent::initEntity($nbt);
        $this->setNameTagVisible(false);
        $this->setNameTagAlwaysVisible(false);
    }

    protected function syncNetworkData(EntityMetadataCollection $properties): void {
        parent::syncNetworkData($properties);
        if ($this->owner !== null) {
            $properties->setLong(EntityMetadataProperties::OWNER_EID, $this->owner->getId());
        }
    }

    public function entityBaseTick(int $tickDiff = 1): bool {
        if ($this->isClosed()) return false;

        $hasUpdate = parent::entityBaseTick($tickDiff);

        if ($this->hookedEntity !== null) {
            if ($this->hookedEntity->isClosed() || $this->hookedEntity->isFlaggedForDespawn()) {
                $this->hookedEntity = null;
            } elseif ($this->owner !== null && $this->owner->isOnline()) {
                $this->tickPull();
            }
            return true;
        }

        if (!$this->inWater) {
            $this->motion = new Vector3(
                $this->motion->x * self::DRAG,
                $this->motion->y - $this->getInitialGravity(),
                $this->motion->z * self::DRAG
            );
            $this->move($this->motion->x, $this->motion->y, $this->motion->z);

            $pos   = $this->location->asVector3();
            $block = $this->getWorld()->getBlock(new Vector3((int)floor($pos->x), (int)floor($pos->y), (int)floor($pos->z)));
            if ($block instanceof Water) {
                $this->onHitWater();
                return true;
            }

            if ($this->owner !== null && $this->owner->isOnline()) {
                if ($pos->distance($this->owner->getLocation()->asVector3()) > 48) {
                    $this->flagForDespawn();
                    return true;
                }
            }

            $this->checkEntityCollision();
        } else {
            $this->tickFloat();
            if ($this->trailActive) {
                $this->tickTrail();
            }
        }

        return $hasUpdate;
    }

    private function onHitWater(): void {
        $this->inWater = true;
        $this->motion  = new Vector3(0, 0, 0);
        $this->setHasGravity(false);

        $pos    = $this->location->asVector3();
        $blockY = (int)floor($pos->y);
        $above  = $this->getWorld()->getBlock(new Vector3((int)floor($pos->x), $blockY + 1, (int)floor($pos->z)));
        $this->waterSurfaceY = ($above instanceof Water) ? ($blockY + 1) + 0.875 : $blockY + 0.875;
        $this->targetY       = $this->waterSurfaceY;
        $this->teleport(new Vector3($pos->x, $this->targetY, $pos->z));

        $this->sendSound("random.splash", $pos, 1.0, 1.0);
    }

    private function tickFloat(): void {
        $pos   = $this->location->asVector3();
        $block = $this->getWorld()->getBlock(new Vector3((int)floor($pos->x), (int)floor($pos->y), (int)floor($pos->z)));

        if (!($block instanceof Water)) {
            $this->inWater     = false;
            $this->trailActive = false;
            $this->setHasGravity(true);
            return;
        }
        $this->bobTick++;
        $bobOffset = sin($this->bobTick * 0.15) * 0.015;
        $newY      = $this->targetY + $bobOffset;

        $pos = $this->location->asVector3();
        if (abs($pos->y - $newY) > 0.001) {
            $this->teleport(new Vector3($pos->x, $newY, $pos->z));
        }
    }

    public function startTrail(): void {
        $this->trailActive   = true;
        $this->trailDone     = false;
        $this->trailTick     = 0;
        $this->trailDuration = mt_rand(40, 80);

        $angle = lcg_value() * M_PI * 2;
        $dist  = lcg_value() * 2.0 + 3.0;
        $pos   = $this->location->asVector3();

        $this->trailStartX = $pos->x + cos($angle) * $dist;
        $this->trailStartZ = $pos->z + sin($angle) * $dist;
    }

    private function tickTrail(): void {
        $this->trailTick++;
        if ($this->trailTick % 2 !== 0) return;

        $progress = min(1.0, $this->trailTick / $this->trailDuration);
        $hookPos  = $this->location->asVector3();
        $surfaceY = $this->waterSurfaceY + 0.12;

        $cx = $this->trailStartX + ($hookPos->x - $this->trailStartX) * $progress;
        $cz = $this->trailStartZ + ($hookPos->z - $this->trailStartZ) * $progress;
        $this->sendParticle("minecraft:water_splash_particle", new Vector3($cx, $surfaceY, $cz));

        if ($progress > 0.05) {
            $prev = max(0.0, $progress - 0.08);
            $px   = $this->trailStartX + ($hookPos->x - $this->trailStartX) * $prev;
            $pz   = $this->trailStartZ + ($hookPos->z - $this->trailStartZ) * $prev;
            $this->sendParticle("minecraft:water_splash_particle", new Vector3($px, $surfaceY, $pz));
        }

        if ($this->trailTick >= $this->trailDuration) {
            $this->onTrailArrived();
        }
    }

    private function onTrailArrived(): void {
        $this->trailActive = false;
        $this->trailDone   = true;

        $pos      = $this->location->asVector3();
        $surfaceY = $this->waterSurfaceY + 0.12;
        $this->targetY = $this->waterSurfaceY - 0.15;

        for ($i = 0; $i < 6; $i++) {
            $ox = (lcg_value() - 0.5) * 0.6;
            $oz = (lcg_value() - 0.5) * 0.6;
            $this->sendParticle("minecraft:water_splash_particle", new Vector3($pos->x + $ox, $surfaceY, $pos->z + $oz));
        }

        $this->sendSound("random.splash", $pos, 0.25, 1.0);
    }

    public function isTrailDone(): bool { return $this->trailDone; }
    private function isNpc(Living $entity): bool {
        if ($entity instanceof Player) return false;
        if ($entity instanceof Human) return true; // Human но не Player = NPC
        return false;
    }

    private function checkEntityCollision(): void {
        $bb = $this->getBoundingBox()->expandedCopy(0.35, 0.35, 0.35);
        foreach ($this->getWorld()->getNearbyEntities($bb, $this) as $entity) {
            if ($entity === $this->owner) continue;
            if (!($entity instanceof Living)) continue;
            if ($entity->isClosed()) continue;
            if ($this->isNpc($entity)) continue;

            $this->hookedEntity = $entity;
            $this->motion       = new Vector3(0, 0, 0);
            $this->teleport($entity->getLocation()->add(0, $entity->getSize()->getHeight() * 0.5, 0));

            if ($this->owner !== null) {
                $ev = new EntityDamageByEntityEvent(
                    $this->owner,
                    $entity,
                    EntityDamageEvent::CAUSE_PROJECTILE,
                    0
                );
                $ev->setKnockBack(0.3);
                $entity->attack($ev);
            }

            $this->sendSound("random.bow_hit", $entity->getLocation()->asVector3(), 1.0, 1.2);
            break;
        }
    }

    private function tickPull(): void {
        if ($this->hookedEntity->isClosed() || $this->hookedEntity->isFlaggedForDespawn()) {
            $this->hookedEntity = null;
            return;
        }
        $this->teleport($this->hookedEntity->getLocation()->add(0, $this->hookedEntity->getSize()->getHeight() * 0.5, 0));

        if ($this->owner !== null) {
            $dist = $this->hookedEntity->getLocation()->distance($this->owner->getLocation());
            if ($dist > 33) {
                $this->hookedEntity = null;
            }
        }
    }

    private function sendParticle(string $name, Vector3 $pos): void {
        $pk = SpawnParticleEffectPacket::create(0, -1, $pos, $name, null);
        foreach ($this->getWorld()->getPlayers() as $p) {
            $p->getNetworkSession()->sendDataPacket($pk);
        }
    }

    private function sendSound(string $sound, Vector3 $pos, float $vol, float $pitch): void {
        $pk = PlaySoundPacket::create($sound, $pos->x, $pos->y, $pos->z, $vol, $pitch);
        foreach ($this->getWorld()->getPlayers() as $p) {
            $p->getNetworkSession()->sendDataPacket($pk);
        }
    }

    public function isInWater(): bool          { return $this->inWater; }
    public function isTrailActive(): bool      { return $this->trailActive; }
    public function getOwner(): ?Player        { return $this->owner; }
    public function getHookedEntity(): ?Entity { return $this->hookedEntity; }
    public function getName(): string          { return "FishingHook"; }
    public function canSaveWithChunk(): bool   { return false; }
}