<?php
declare(strict_types=1);

namespace MinePlugins\FishingRod\loot;

use MinePlugins\FishingRod\event\PlayerFishEvent;
use MinePlugins\FishingRod\Main;
use pocketmine\item\Item;
use pocketmine\item\ItemFactory;
use pocketmine\item\VanillaItems;

class LootTable {
  
    public static function roll(int $fortuneLevel = 0): array {
        $config = Main::getInstance()->getConfig();
        $fishChance     = (int) $config->getNested("loot.fish_chance",     60);
        $treasureChance = (int) $config->getNested("loot.treasure_chance", 20);
        $roll = mt_rand(1, 100);

        if ($roll <= $fishChance) {
            $category = PlayerFishEvent::CATEGORY_FISH;
            $pool     = $config->getNested("loot.fish", []);
        } elseif ($roll <= $fishChance + $treasureChance) {
            $category = PlayerFishEvent::CATEGORY_TREASURE;
            $pool     = $config->getNested("loot.treasure", []);
        } else {
            $category = PlayerFishEvent::CATEGORY_JUNK;
            $pool     = $config->getNested("loot.junk", []);
        }

        $item = self::pickFromPool($pool);

        return ["item" => $item, "category" => $category];
    }
    private static function pickFromPool(array $pool): Item {
        if (empty($pool)) {
            return VanillaItems::RAW_FISH();
        }
        $totalWeight = array_sum(array_column($pool, "weight"));
        $rand        = mt_rand(1, max(1, $totalWeight));

        $cumulative = 0;
        foreach ($pool as $entry) {
            $cumulative += (int) ($entry["weight"] ?? 1);
            if ($rand <= $cumulative) {
                return self::buildItem($entry);
            }
        }

        return self::buildItem(end($pool));
    }
    private static function buildItem(array $entry): Item {
        $id    = (int) ($entry["id"]    ?? 349);
        $meta  = (int) ($entry["meta"]  ?? 0);
        $count = (int) ($entry["count"] ?? 1);

        try {
            $item = ItemFactory::getInstance()->get($id, $meta, max(1, $count));
        } catch (\Throwable) {
            $item = VanillaItems::RAW_FISH();
        }

        return $item;
    }
}